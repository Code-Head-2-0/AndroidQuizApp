##  Quiz Application ## 
* An interactive quiz application which shows 5 questions on the interface, one by one.
* Questions are retrieved randomly from SQLite database. (The database is scalable. Can
  add any no of questions. Currently the app contains 50 questions)
* Calculates the total score and shows the result at the end.

#### Screenshots ####

![Alt text](quizapp.png?raw=true "Title")
